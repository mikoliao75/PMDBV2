var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/node_modules_cd1b5fda._.js")
R.c("server/chunks/ssr/[root-of-the-server]__fa248b9f._.js")
R.m("[project]/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/document.js [ssr] (ecmascript)").exports
