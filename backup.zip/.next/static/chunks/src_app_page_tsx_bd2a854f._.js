(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_a0503d52._.js",
  "static/chunks/node_modules_next_52819f75._.js",
  "static/chunks/node_modules_lodash_034a0376._.js",
  "static/chunks/node_modules_recharts_es6_ca98ccd3._.js",
  "static/chunks/node_modules_zod_v3_7a2e3c82._.js",
  "static/chunks/node_modules_@radix-ui_0f4be87d._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_d2c5a6f7._.js"
],
    source: "dynamic"
});
