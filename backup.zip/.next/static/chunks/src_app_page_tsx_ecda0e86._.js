(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_firebase_dfd8c92f._.js",
  "static/chunks/src_9a9b4ae1._.js",
  "static/chunks/node_modules_next_316b6cde._.js",
  "static/chunks/node_modules_lodash_034a0376._.js",
  "static/chunks/node_modules_recharts_es6_ca98ccd3._.js",
  "static/chunks/node_modules_zod_v3_7a2e3c82._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_b45f2044._.js",
  "static/chunks/node_modules_@radix-ui_0f4be87d._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_@firebase_c6a70eba._.js",
  "static/chunks/node_modules_581c4d6f._.js"
],
    source: "dynamic"
});
