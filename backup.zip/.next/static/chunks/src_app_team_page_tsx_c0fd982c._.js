(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_8626e2a5._.js",
  "static/chunks/node_modules_652f2964._.js"
],
    source: "dynamic"
});
