(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_109bd1db._.js",
  "static/chunks/node_modules_lodash_034a0376._.js",
  "static/chunks/node_modules_recharts_es6_ca98ccd3._.js",
  "static/chunks/node_modules_zod_v3_7a2e3c82._.js",
  "static/chunks/node_modules_@radix-ui_d576186e._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_07266a7a._.js"
],
    source: "dynamic"
});
