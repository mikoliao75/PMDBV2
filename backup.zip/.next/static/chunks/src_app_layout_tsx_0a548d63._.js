(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__917f460a._.css",
  "static/chunks/node_modules_firebase_00eff6a9._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_b45f2044._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_33cb7cab._.js",
  "static/chunks/src_5f201f71._.js"
],
    source: "dynamic"
});
