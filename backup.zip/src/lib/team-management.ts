'use client';

import { useState } from 'react';
import { useCollection } from '@/firebase/firestore/use-collection'; // 你的 useCollection hook 路徑
import { useFirestore } from '@/firebase'; // 正確取得 db
import { collection, doc, writeBatch, deleteDoc, where, query, getDocs } from 'firebase/firestore';
import { Member, Project } from './types';
import { useToast } from '@/hooks/use-toast';

const MANAGER_ID = 'your-manager-id'; // **重要：請替換為實際經理的用戶 ID**

export function useTeamManagement() {
  const db = useFirestore(); // 從 Firebase Context 取得 db
  const { data: users, loading: usersLoading, error: usersError } = useCollection<Member>(collection(db, 'users'));
  const { data: projects, loading: projectsLoading, error: projectsError } = useCollection<Project>(collection(db, 'projects'));
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 計算單一成員的工作量
  const calculateWorkload = (memberId: string) => {
    const member = users?.find(u => u.id === memberId);
    if (!projects || !member) return { currentLoad: 0, weeklyWorkHoursLimit: 40, isOverloaded: false };

    const assignedProjects = projects.filter(p => p.assigneeId === memberId);
    const currentLoad = assignedProjects.reduce((total, p) => {
      const projectBaseLoad = 40 * (1 - (p.progress || 0) / 100);
      const subTasksLoad = (p.actionItems?.length || 0) * 4; // 每個行動項目計 4 小時
      return total + projectBaseLoad + subTasksLoad;
    }, 0);

    const isOverloaded = currentLoad > member.weeklyWorkHoursLimit;

    // 工作量超標時，記錄警告（可擴充為自動更新專案狀態）
    if (isOverloaded) {
      console.warn(`成員 ${member.name} 工作量超標: ${currentLoad} / ${member.weeklyWorkHoursLimit}`);
    }

    return { currentLoad, weeklyWorkHoursLimit: member.weeklyWorkHoursLimit, isOverloaded };
  };

  // 新增成員
  const addMember = async (data: Omit<Member, 'id' | 'avatar' | 'projects'>) => {
    setIsSubmitting(true);
    try {
      const batch = writeBatch(db);
      const newUserRef = doc(collection(db, 'users'));
      const newMember = {
        ...data,
        id: newUserRef.id,
        avatar: `/avatars/${Math.ceil(Math.random() * 5)}.png`,
        projects: [],
      };
      batch.set(newUserRef, newMember);
      await batch.commit();
      toast({ title: '成功', description: '新成員已成功新增。' });
    } catch (error) {
      console.error("Error adding member: ", error);
      toast({ title: '錯誤', description: '新增成員失敗，請稍後再試。', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // 更新成員
  const updateMember = async (memberId: string, data: Partial<Member>) => {
    setIsSubmitting(true);
    try {
      const batch = writeBatch(db);
      const memberRef = doc(db, 'users', memberId);
      batch.update(memberRef, data);
      await batch.commit();
      toast({ title: '成功', description: '成員資料已更新。' });
    } catch (error) {
      console.error("Error updating member: ", error);
      toast({ title: '錯誤', description: '更新成員失敗。', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // 刪除成員（樂觀更新 + 失敗還原 + 重新分配專案給經理）
  const deleteMember = async (memberId: string) => {
    setIsSubmitting(true);

    const originalUsers = users ? [...users] : [];
    // 樂觀更新（可選，如果 UI 需要即時反應）
    // setUsers(current => current?.filter(u => u.id !== memberId) || null);

    try {
      const batch = writeBatch(db);

      // 1. 重新分配專案給經理
      const q = query(collection(db, 'projects'), where('assigneeId', '==', memberId));
      const projectsSnapshot = await getDocs(q);
      projectsSnapshot.forEach(projectDoc => {
        const projectRef = doc(db, 'projects', projectDoc.id);
        batch.update(projectRef, { assigneeId: MANAGER_ID });
      });

      // 2. 刪除成員
      const memberRef = doc(db, 'users', memberId);
      batch.delete(memberRef);

      await batch.commit();
      toast({ title: '刪除成功', description: '成員已被刪除，其專案已重新指派給經理。' });
    } catch (error) {
      console.error("Error deleting member: ", error);
      toast({ title: '刪除失敗', description: '操作失敗，請檢查權限或網路連線。', variant: 'destructive' });
      // 失敗時還原狀態（如果有樂觀更新）
      // setUsers(originalUsers);
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    users,
    usersLoading,
    usersError,
    addMember,
    updateMember,
    deleteMember,
    calculateWorkload,
    isSubmitting,
  };
}